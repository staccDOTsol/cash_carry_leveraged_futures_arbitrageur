from cryptofeed.rest.rest import Rest
