import os
apikey = os.environ['key']
apisecret = os.environ['secret']
divisor=100

import requests 
import math
from datetime import timedelta
import datetime
import sys
import threading
import linecache
from time import sleep
coinsto = ['BTC', 'ETH', 'XRP', 'BCH', 'LTC', 'EOS']
wantingold = {}
for coin in coinsto:
    wantingold[coin] = None
import ccxt
binance	 = ccxt.binance({'enableRateLimit': True,
"options":{"defaultMarket":"futures"},
'urls': {'api': {
                         'public': 'https://dapi.binance.com/dapi/v1',
                         'private': 'https://dapi.binance.com/dapi/v1',},}
})

#print(dir(binance))
sleep(1)
SECONDS_IN_DAY	  = 3600 * 24
from cryptofeed import FeedHandler
from cryptofeed import FeedHandler
from cryptofeed.callback import BookCallback, TickerCallback, TradeCallback
from cryptofeed.defines import TICKER_FUTURES, TICKER_OKS, BID, ASK, FUNDING, L2_BOOK, OPEN_INTEREST, TICKER, TRADES
from cryptofeed.exchanges import OKEx, KrakenFutures, BinanceFutures, FTX
from cryptofeed.exchanges import HuobiDM as hdm
fh = FeedHandler()
fundingwinners = []
from flask import Flask

from flask_cors import CORS, cross_origin
app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'

from flask import jsonify

minArb = 0.015
print(minArb)

minArb = minArb * 75
print(minArb)
minArb = minArb * 365 
print(minArb)
premiumwinners = []
@app.route('/json')
def summary():
    global fundingwinners, premiumwinners
    return jsonify({'premiumwinners': premiumwinners, 'fundingwinners': fundingwinners})

def loop_in_thread():
    fh.run()
def loop_in_thread2():
    app.run(host='0.0.0.0', port=8080)

def PrintException():
	exc_type, exc_obj, tb = sys.exc_info()
	f = tb.tb_frame
	lineno = tb.tb_lineno
	filename = f.f_code.co_filename
	linecache.checkcache(filename)
	line = linecache.getline(filename, lineno, f.f_globals)
	string = 'EXCEPTION IN ({}, LINE {} "{}"): {}'.format(filename, lineno, line.strip(), exc_obj)
	print	(string)
	if 'UNI' not in string and 'PostCross' not in string and 'PostFuture' not in string:
		sleep(0.1)
#		if 'Account does not have enough margin for order' not in string:
			#sleep(1)
async def ticker(feed, pair, bid, ask, timestamp, ex):
    global mids
    #print(f'Ex?: {ex} Timestamp: {timestamp} Feed: {feed} Pair: {pair} Bid: {bid} Ask: {ask}')
    if 'OKEX' in feed.upper():
        ex = 'ftx'
        if 'USDT' not in pair:
            name = pair.split('-')[0]
            if '-' not in pair:
                return
            dt = pair[-4:]
            if dt == 'SWAP':
                dt = 'PERP'
            #print(pair)
        else:
            return
    elif 'FTX' in feed:
        ex = 'ftx'
        name = pair.split('-')[0]
        if '-' not in pair:
            return
        dt = pair.split('-')[1]
        #print(dt)
    elif 'KRAKEN' in feed:
        if 'PI' in pair:
            p = pair.split('_')[1]
            name = p.replace('USD','').replace('XBT','BTC')
            dt = 'PERP'
        else:
            name = pair.split('_')[1].split('_')[0].replace('USD', '').replace('XBT', 'BTC')
            dt = pair[-4:]
        ex = 'kraken'
    elif 'BINANCE' in feed:
        #ETH-USD_200925
        name = pair.split('-')[0]
        dt = pair[-4:]
        ex = 'binance'
        #print(dt)
 
   # print(feed + '-' + name + '-' + dt +': ' + str( 0.5 * ( float(bid) + float(ask))))
    mids[ex][name + '-' + dt] = 0.5 * ( float(ask) + float(bid))
    bids[ex][name + '-' + dt] = float(bid)
    asks[ex][name + '-' + dt] = float(ask) 
pairs = {}
async def book(feed, pair, book, timestamp, receipt_timestamp):
    global mids, pairs
    hb = 0
    la = 99999999999999
    for bid in book[BID]:
        if bid > hb:
            hb = bid
    for ask in book[ASK]:
        if ask < la:
            la = ask
    #print(pair)
    dt = pair[-4:]

    name = pair.split('21')[0].split('21')[0].split('20')[0].split('20')[0]
    pairs[name + '-' + dt] = pair
    #print(name)
  #  if 'BTC' in name and lastex != feed and lastbtc != 0.5 * ( float(bid) + float(ask)):
    #    lastex = feed
   #     lastbtc = 0.5 * ( float(bid) + float(ask))
        #print(feed + '-' + name + '-' + dt +': ' + str( 0.5 * ( float(bid) + float(ask))))
    #print(pair)
    #print(name + '-' + dt)
    if name in coinsto:
        mids['huobi'][name + '-' + dt] = 0.5 * ( float(la) + float(hb))
        #print(mids)
        bids['huobi'][name + '-' + dt] = float(hb)
        asks['huobi'][name + '-' + dt] = float(la) 
    #print(f'Timestamp: {timestamp} Feed: {feed} Pair: {pair} Book Bid Size is {len(book[BID])} Ask Size is {len(book[ASK])}')
def cancelall():
    try:
        #print()
        """
        ords = ftx.fetchOpenOrders( )
        for order in ords:
            ###print(order)
            oid = order['info'] ['id']
            #print(order)
           # sleep(100)
           # ##print(order)
            try:
                
                ftx.cancelOrder( oid , order['info']['future'])
            except Exception as e:
                PrintException()

        """
    except Exception as e:
        PrintException()
arbwinnersavg = []
arbwinnersc = []
maxmax = 0
def doCalc():
    try:
        global premiumwinners, arbwinnersc, arbwinnersavg, maxmax
        for contract in huobisw:
            if contract.split('-')[0] in huobis and contract.split('-')[0] in coinsto:
                data = requests.get("https://api.hbdm.com/swap-ex/market/detail/merged?contract_code=" + contract).json()['tick']
                ask = data['ask'][0]
                bid = data['bid'][0]
                name = contract.split('-')[0]
                dt = 'PERP'
                ex = 'huobi'
                mids[ex][name + '-' + dt] = 0.5 * ( float(ask) + float(bid))
                bids[ex][name + '-' + dt] = float(bid)
                asks[ex][name + '-' + dt] = float(ask) 
                #print(name)
        dts = []
        coins = []
        tempmids = mids
        for ex in tempmids:
            for coin in tempmids[ex]:
                
                #print(coin)
                if coin.split('-')[1] not in dts:
                    dts.append(coin.split('-')[1])
                if coin.split('-')[0] not in coins:
                    coins.append(coin.split('-')[0].split('20')[0].split('21')[0])
        arbs = {}
        exes = {}
        #print(expis)
        for contract in huobis:
            for exp in expis:
                sizeIncrements[contract + '-' + exp] = sizeIncrements[contract]
                
        for coin in coins:
            arbs[coin] = {}
            exes[coin] = {}
            for ex in tempmids:
                for dt in expis:
                    arbs[coin][dt] = []
                    exes[coin][dt] = {}
        for coin in coins:
            for ex in tempmids:
                for dt in tempmids[ex]:
                    try:
                        
                        exes[coin][dt.split('-')[1]][tempmids[ex][dt]] = ex
                    except:
                        abc=123
                      #  PrintException()
                   # print(dt)
                    if coin in dt:
                        
                        try:
                            if '-' in dt:
                                if 'e' not in str(tempmids[ex][dt]):
                                
                                    arbs[coin][dt.split('-')[1]].append(tempmids[ex][dt])
                                
                        except:
                            PrintException()
                            abc=123
        
        
        perps = {}
        lalaexes = {}
        for coin in coins:
            for ex in tempmids:
                for dt in tempmids[ex]:
                   # print(dt)
                    if coin in dt and 'PERP' in dt:
                        perps[coin] = tempmids[ex][dt]
                        lalaexes[coin] = ex
                        
        for coin in arbs:
            for dt in arbs[coin]:
                try:
                    if '-' in dt:
                        if 'e' not in str(perps[coin]):
                            arbs[coin][dt].append(perps[coin])
                            exes[coin][dt][perps[coin]] = lalaexes[coin]
                except:
        #            PrintException()
                    PrintException()
        #print(exes)
        #print(arbs)
        #print(expis)
        thearbs = []
        coinarbs = {}
        minmax = {}
        windts = {}
        winprices = {}
        for coin in arbs:
            minmax[coin] = []
            windts[coin] = {}
            winprices[coin] = {}
            for dt in expis:
                if dt != 'PERP':
                    try:
                        #print(len(arbs[coin][dt]))
                        #if len(arbs[coin][dt]) > 0:
                        minmax[coin].append(math.fabs(tempmids['huobi'][coin + '-' + dt] - tempmids['huobi'][coin + '-PERP']))
                        windts[coin][math.fabs(tempmids['huobi'][coin + '-' + dt] - tempmids['huobi'][coin + '-PERP'])] = dt
                        winprices[coin][math.fabs(tempmids['huobi'][coin + '-' + dt] - tempmids['huobi'][coin + '-PERP'])] = tempmids['huobi'][coin + '-' + dt]
                        #minimum = tempmids['ftx'][coin + '-PERP']  #10900/10709 #pos long perp, neg short perp
                    except:
                        PrintException()
                        abc=123
        for coin in arbs:

            try:
                maximum = max(minmax[coin])
                
                windt = windts[coin][maximum]
                maximum = winprices[coin][maximum]
                minimum = tempmids['huobi'][coin + '-PERP']
                #maximum = tempmids['ftx'][coin + '-' + dt] #pos short fut, neg long fut #pos long perp, neg short perp
     #           if coin == 'BTC':
     ##               print(arbs[coin][dt])
      #              print(maximum / minimum)
                thearb = ((((maximum / minimum)-1)*100)*365*10) #1.1/1.05 = 
                #print(thearb)
                #print(expis[dt])
                #print('thearb of ' + coin + ' at ' + dt + ' in total ' + str(thearb)) 
                thearb = thearb / expis[windt] 
                
                #print(thearb)
                #print( ' ' )
                thearb = thearb #- 36
                coinarbs[thearb] = coin + '-' + windt 
                if thearb > 10 or thearb < -10:
                    thearbs.append(thearb)
                    print(thearb)
                    #print(coinarbs[thearb])
                    print(windt)
                    print(maximum)
                    print(minimum)
                else:
                    thearbs.append(0)
                """
                if thearb > 10 and coin != 'USDT':
                   # print(exes[coin][dt])
                    thearbs.append({'exlong': exes[coin][dt][minimum], 'exshort': exes[coin][dt][maximum], 'coin': coin, 'thearb': thearb, 'dt': dt, 'arbscoindt': arbs[coin][dt]})
                    print({'exlong': exes[coin][dt][minimum], 'exshort': exes[coin][dt][maximum], 'coin': coin, 'thearb': thearb, 'dt': dt, 'arbscoindt': arbs[coin][dt]})
                """
              #  print('and after figuring out daily arb it\'s ' +  str(thearb))
                
            except:
                PrintException()
                #PrintException()
                abc=123#PrintException()
        t = 0
        c = 0
        #print(thearbs)
        for arb in thearbs:
            
            t = t + math.fabs(arb)
            if arb != 0:
                c = c + 1
        percs = {}
        wanting = {}
        if c > 0:
            avg = t / c
            c1 = c
            
            t = 0 
            c = 0 
            maxi = 0
            for arb in thearbs:
                if math.fabs(arb) > avg:
                    print(coinarbs[arb] + ' is a good coin no?')
                    if arb > maxi:
                        maxi = arb
                    if arb > maxmax:
                        maxmax = arb
                    t = t + math.fabs(arb)
                    c = c + 1
            for arb in thearbs:
                try:
                    if arb in coinarbs:
                        if '-' in coinarbs[arb]:
                            if math.fabs(arb) > avg:
                                percs[coinarbs[arb].split('-')[0]] = arb / t
                                if coinarbs[arb] in usdpos: #-0.3 * 10 * 100 + 360 #-0.16*400*10+1826=1186
                                                                                   #-0.16*400*10-266=-906
                                    wanting[coinarbs[arb]] = arb / t * 10 * balance
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] * -1
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] # - usdpos[coinarbs[arb]]
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] / 10
                                    wanting[coinarbs[arb]] = round(wanting[coinarbs[arb]] / 100) * 100
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] * 10
                                
                                else:
                                    wanting[coinarbs[arb]] = arb / t * 10 * balance
                                    
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] * -1
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] / 10
                                    wanting[coinarbs[arb]] = round(wanting[coinarbs[arb]] / 100) * 100
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] * 10
                                if coinarbs[arb].split('-')[0] + '-PERP' in usdpos:
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] =  percs[coinarbs[arb].split('-')[0]] * 10 * balance #- usdpos[coinarbs[arb].split('-')[0] + '-PERP']
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = wanting[coinarbs[arb].split('-')[0] + '-PERP'] / 10
                                    
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = round(wanting[coinarbs[arb].split('-')[0] + '-PERP'] / 100) * 100
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = wanting[coinarbs[arb].split('-')[0] + '-PERP'] * 10
                                else:
                                   # if percs[coinarbs[arb].split('-')[0]] > 0:
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] =  percs[coinarbs[arb].split('-')[0]] * 10 * balance
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = wanting[coinarbs[arb].split('-')[0] + '-PERP'] / 10
                                    
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = round(wanting[coinarbs[arb].split('-')[0] + '-PERP'] / 100) * 100
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = wanting[coinarbs[arb].split('-')[0] + '-PERP'] * 10
                                
                            else:
                                #if arb != 0:
                                
                                if arb in coinarbs:
                                    if '-' in coinarbs[arb]:
                                        percs[coinarbs[arb].split('-')[0]] = 0
                                        if coinarbs[arb] in usdpos:
                                        
                                            wanting[coinarbs[arb]] = -1 #* usdpos[coinarbs[arb]]
                                            wanting[coinarbs[arb]] = wanting[coinarbs[arb]] / 10
                                            wanting[coinarbs[arb]] = round(wanting[coinarbs[arb]] / 100) * 100
                                            wanting[coinarbs[arb]] = wanting[coinarbs[arb]] * 10
                                        else:
                                            
                                            wanting[coinarbs[arb]] = 0
                                        if coinarbs[arb].split('-')[0] + '-PERP' in usdpos:
                                            wanting[coinarbs[arb].split('-')[0] + '-PERP'] = -1 #* usdpos[coinarbs[arb].split('-')[0] + '-PERP']
                                            wanting[coinarbs[arb].split('-')[0] + '-PERP'] = wanting[coinarbs[arb].split('-')[0] + '-PERP'] / 10
                                
                                            wanting[coinarbs[arb].split('-')[0] + '-PERP'] = round(wanting[coinarbs[arb].split('-')[0] + '-PERP'] / 100) * 100
                                            wanting[coinarbs[arb].split('-')[0] + '-PERP'] = wanting[coinarbs[arb].split('-')[0] + '-PERP'] * 10
                                        else:
                                        
                                            wanting[coinarbs[arb].split('-')[0] + '-PERP'] =  0
                                                
                                    
                            
                except:
                    PrintException()
            for pos2 in usdpos:
                if pos2 not in wanting:
                    if usdpos[pos2] != 0:
                        #wanting[pos2] = -1 * usdpos[pos2]
                        print(pos2)
                        print(wanting)
                        #sleep(10)
            print(wanting)
            twanting = {}
            futwants = {}
            lowers = {}
            counts = {}
            twanting = {}
            for arb in wanting:
                lowers[arb] = 999999999999999
                counts[arb.split('-')[0]] = 0
                
                twanting[arb] = 0
            for arb in wanting:
                if 'PERP' not in arb:
                    futwants[arb.split('-')[0]] = 0
                    
                    counts[arb.split('-')[0]] = counts[arb.split('-')[0]] + 1
                    #twanting[arb.split('-')[0] + '-PERP'] = wanting[arb.split('-')[0] + '-PERP'] + wanting[arb]
            
            for arb in wanting:
                if 'PERP' not in arb:
                    futwants[arb.split('-')[0]] = futwants[arb.split('-')[0]] + wanting[arb]
                    
            for arb in futwants:
                for coin in wanting:
                    if 'PERP' in coin:
                        twanting[coin] = futwants[coin.split('-')[0]] * -1
                    else:
                        twanting[coin] = wanting[coin]
            wanting = twanting
            print(wanting)
           
            
           # wanting = twanting
            for arb in wanting:
                if 'PERP' in arb:
                    toborrow = math.fabs(wanting[arb]) / 10
                    toborrow = math.floor((toborrow * 1.02) / 100) * 100  
            
                    print(toborrow)
                    if toborrow > 0:
                        if arb.split('-')[0] in marginbs:
                            toborrow = toborrow - marginbs[arb.split('-')[0]]#1.2345 * 1000
                        toborrow = toborrow / mids['huobi'][arb]
                        print(toborrow)
                        toborrow = math.floor(toborrow * 1000) / 1000
                        print(arb)
                        print(toborrow)
                        print({'symbol': arb.split('-')[0].lower() + 'usdt', 'currency': arb.split('-')[0].lower(), 'amount':  str( toborrow)})
                        if wantingold[arb.split('-')[0]] == None or wantingold[arb.split('-')[0]] < toborrow:
                            try:
                                
                                borrowed = hspot.privatePostCrossMarginOrders({'symbol': arb.split('-')[0].lower() + 'usdt', 'currency': arb.split('-')[0].lower(), 'amount':  str( round((toborrow * 1.01) * 1000)/ 1000)})   
                            except Exception as e:
                                PrintException()
                                sleep(2)
                            finally:
                                wantingold[arb.split('-')[0]] = toborrow
                        if wantingold[arb.split('-')[0]] == None or wantingold[arb.split('-')[0]] > toborrow:
                            try:
                                try:
                                    hspot.v2PrivatePostAccountTransfer({'from': 'swap', 'to': 'spot', 'currency': arb.split('-')[0].lower(), 'amount': str(wantingold[arb.split('-')[0]] / mids['huobi'][arb]- (toborrow / 2) / mids['huobi'][arb])}) 
                                except:
                                    PrintException()
                                try:
                                    hspot.privatePostFuturesTransfer({'type': 'futures-to-pro', 'currency': arb.split('-')[0].lower(), 'amount': str(wantingold[arb.split('-')[0]] / mids['huobi'][arb]- (toborrow / 2) / mids['huobi'][arb])})
                                except:
                                    PrintException()
                                try:
                                    hspot.privatePostCrossMarginTransferIn({'currency': arb.split('-')[0].lower(), 'amount': str(toborrow / mids['huobi'][arb])})
                                except:
                                    PrintException()
                                try:
                                    loans = hspot.privateGetCrossMarginLoanOrders({'size': "100",'currency': arb.split('-')[0].lower(), 'state': 'accrual'})
                                except:
                                    PrintException()
                                for l in loans['data']:
                                    try:
                                        if float(l['loan-balance']) > 0:
                                            torepay = float(l['loan-balance'])
                                            torepayi = float(l['interest-amount'])
                                            try:
                                                hspot.v2PrivatePostAccountTransfer({'from': 'swap', 'to': 'spot', 'currency': arb.split('-')[0].lower(), 'amount': str(torepayi / 2)}) 
                                            except:
                                                PrintException()
                                            try:
                                                hspot.privatePostFuturesTransfer({'type': 'futures-to-pro', 'currency': arb.split('-')[0].lower(), 'amount': str(torepayi / 2)})
                                            except:
                                                PrintException()
                                            try:
                                                hspot.privatePostCrossMarginTransferIn({'currency': arb.split('-')[0].lower(), 'amount': str(torepayi)})
                                            except:
                                                PrintException()
                                            identifier = l['id']
                                            hspot.privatePostCrossMarginOrdersIdRepay({'id': identifier, 'amount': str(torepay)})
                                            #hspot.privatePostCrossMarginOrdersIdRepay({'id': identifier, 'amount': str(toborrow / mids['huobi'][arb])})
                                    except Exception as e:
                                        PrintException()
                                        sleep(2)
                            except Exception as e:
                                PrintException()
                                sleep(2)
                            finally:
                                wantingold[arb.split('-')[0]] = toborrow 
                                
                        #print(borrowed)
            print('111')
            print(wanting)
            for arb in thearbs:
                try:
                
                    if arb in coinarbs:
                        if '-' in coinarbs[arb]:
                            if math.fabs(arb) > avg:
                                percs[coinarbs[arb].split('-')[0]] = arb / t
                                if coinarbs[arb] in usdpos: #-0.3 * 10 * 100 + 360 #-0.16*400*10+1826=1186
                                                                                   #-0.16*400*10-266=-906
                                    wanting[coinarbs[arb]] = arb / t * 10 * balance
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] * -1
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]]  - usdpos[coinarbs[arb]]
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] / 10
                                    wanting[coinarbs[arb]] = round(wanting[coinarbs[arb]] / 100) * 100
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] * 10
                                
                                else:
                                    wanting[coinarbs[arb]] = arb / t * 10 * balance
                                    
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] * -1
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] / 10
                                    wanting[coinarbs[arb]] = round(wanting[coinarbs[arb]] / 100) * 100
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] * 10
                                if coinarbs[arb].split('-')[0] + '-PERP' in usdpos:
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] =  percs[coinarbs[arb].split('-')[0]] * 10 * balance - usdpos[coinarbs[arb].split('-')[0] + '-PERP']
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = wanting[coinarbs[arb].split('-')[0] + '-PERP'] / 10
                                    
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = round(wanting[coinarbs[arb].split('-')[0] + '-PERP'] / 100) * 100
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = wanting[coinarbs[arb].split('-')[0] + '-PERP'] * 10
                                else:
                                   # if percs[coinarbs[arb].split('-')[0]] > 0:
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] =  percs[coinarbs[arb].split('-')[0]] * 10 * balance
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = wanting[coinarbs[arb].split('-')[0] + '-PERP'] / 10
                                    
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = round(wanting[coinarbs[arb].split('-')[0] + '-PERP'] / 100) * 100
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = wanting[coinarbs[arb].split('-')[0] + '-PERP'] * 10
                                
                            else:
                                #if arb != 0:
                                percs[coinarbs[arb].split('-')[0]] = 0
                                if coinarbs[arb] in usdpos:
                                
                                    wanting[coinarbs[arb]] = -1 * usdpos[coinarbs[arb]]
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] / 10
                                    wanting[coinarbs[arb]] = round(wanting[coinarbs[arb]] / 100) * 100
                                    wanting[coinarbs[arb]] = wanting[coinarbs[arb]] * 10
                                else:
                                    
                                    wanting[coinarbs[arb]] = 0
                                if coinarbs[arb].split('-')[0] + '-PERP' in usdpos:
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = -1 * usdpos[coinarbs[arb].split('-')[0] + '-PERP']
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = wanting[coinarbs[arb].split('-')[0] + '-PERP'] / 10
                        
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = round(wanting[coinarbs[arb].split('-')[0] + '-PERP'] / 100) * 100
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] = wanting[coinarbs[arb].split('-')[0] + '-PERP'] * 10
                                else:
                                
                                    wanting[coinarbs[arb].split('-')[0] + '-PERP'] =  0
                                        
                            
                    
                except:
                    PrintException()
            for pos2 in usdpos:
                if pos2 not in wanting:
                    if usdpos[pos2] != 0:
                        wanting[pos2] = -1 * usdpos[pos2]
                        print(pos2)
                        print(wanting)
                        #sleep(10)
            print(wanting)
            twanting = {}
            futwants = {}
            lowers = {}
            counts = {}
            twanting = {}
            for arb in wanting:
                lowers[arb] = 999999999999999
                counts[arb.split('-')[0]] = 0
                
                twanting[arb] = 0
            for arb in wanting:
                if 'PERP' not in arb:
                    futwants[arb.split('-')[0]] = 0
                    
                    counts[arb.split('-')[0]] = counts[arb.split('-')[0]] + 1
                    #twanting[arb.split('-')[0] + '-PERP'] = wanting[arb.split('-')[0] + '-PERP'] + wanting[arb]
            
            for arb in wanting:
                if 'PERP' not in arb:
                    futwants[arb.split('-')[0]] = futwants[arb.split('-')[0]] + wanting[arb]
                    
            for arb in futwants:
                for coin in wanting:
                    if 'PERP' in coin:
                        twanting[coin] = futwants[coin.split('-')[0]] * -1
                    else:
                        twanting[coin] = wanting[coin]
            wanting = twanting
            print(wanting)
           
            
            #pos short fut, neg long fut #pos long perp, neg short perp
            for coin in wanting:
                #wanting[coin] = round(wanting[coin] / (100 * 10)) * (100 * 10) 
                wanting[coin] = wanting[coin]  / (50) #/ mids['huobi'][coin]
                #   round(0.1 * (0.1)) / 0.1
                # abc = -937.0961358420444
                # abc = abc / 28 / 10
                # abc = ( round(abc * (0.1)) / 0.1)
                wanting[coin] = round(wanting[coin] / 10) * 1
                
            print('222')
            print(wanting)
            
            #wanting = twanting
            print(twanting)
            
            print(wanting)      
            
            #for arb in wanting:
            #    if wanting[arb] < lowers[arb]:
            #        lowers[arb] = wanting[arb]
            #wanting = lowers
            #print(wanting['CREAM-PERP'])
            #sleep(100)
            for coin in wanting:
                try:
                    direction = 'buy'
                    prc = bids['huobi'][coin]
                    go = False
                    if coin.split('-')[0] not in skews:
                        skews[coin.split('-')[0]] = 0
                    if wanting[coin] > 0:
                        go = True
                        print('1')
                        try:
                            if skews[coin.split('-')[0]] > wanting[coin] * 1.1:# * mids['huobi'][coin]:
                                print('cancel2!')
                                #ords = ftx.fetchOpenOrders( coin )
                                gogo = True
                                #for o in ords:
                                #    ftx.cancelOrder( o['info']['id'] , o['info']['future'])
                                #go = False
                        except:
                            PrintException()
                    if wanting[coin] < 0:
                        go = True
                        print('3')
                        try:
                            if skews[coin.split('-')[0]] < wanting[coin] * 1.1: #* tempmids['huobi'][coin]:   
                                
                                #ords = ftx.fetchOpenOrders( coin )
                                gogo = True
                                #for o in ords:
                                #    ftx.cancelOrder( o['info']['id'] , o['info']['future'])
                                #print('cancel!')
                                #go = False
                        except:
                            PrintException()
                        wanting[coin] = wanting[coin] * -1
                        direction = 'sell'
                        prc = asks['huobi'][coin]
                    if go == True:
                       # sleep(1)
                        try:
                            #ords = ftx.fetchOpenOrders( coin )
                            gogo = True
                            if 'PERP' not in coin:
                                ords = hfutures.privatePostContractOpenorders({'symbol': coin.split('-')[0]})
                                
                                for o in ords['data']['orders']:
                                    if direction == o['direction'] and o['symbol'] + '-' + o['contract_code'][:-4] == coin:
                                        #gogo = False
                                        qty = o['volume'] 
                                        if direction == 'sell' and skews[coin.split('-')[0]] > wanting[coin] * 1.1 * mids['huobi'][coin] or direction == 'buy' and skews[coin.split('-')[0]] < wanting[coin] * 1.1 * mids['huobi'][coin]:
                                            if prc != o['price']:
                                                ordid = o['order_id']
                                                e = hfutures.privatePostContractCancel( {'symbol': coin.split('-')[0], 'order_id': str(ordid)} )
                                                
                                        #PrintException()
                            
                                if gogo == True:
                                    if direction == 'sell' and skews[coin.split('-')[0]] > wanting[coin] * 1.1  or direction == 'buy' and skews[coin.split('-')[0]] < wanting[coin] * 1.1 * mids['huobi'][coin]:
                                        if usdpos[coin.split('-')[0]] < wanting[coin]:
                                            offset = 'open'
                                        else:
                                            offset = 'close'    
                                        hfutures.privatePostContractOrder( {'offset': offset,'contract_code': pairs[coin], 'price': prc, 'volume': wanting[coin], 'direction': direction, 'lever_rate': 10, 'order_price_type': 'post_only'})
                            else:
                                ords = hswap.privatePostSwapOpenorders({'contract_code': coin.replace('PERP', 'USD')})
                                
                                for o in ords['data']['orders']:
                                    if direction == o['direction'] and o['symbol']  == coin.split('-')[0]:
                                        #gogo = False
                                        qty = o['volume'] 
                                        if direction == 'sell' and skews[coin.split('-')[0]] > wanting[coin] * 1.1 * mids['huobi'][coin] or direction == 'buy' and skews[coin.split('-')[0]] < wanting[coin] * 1.1 * mids['huobi'][coin]:
                                            if prc != o['price']:
                                                ordid = o['order_id']
                                                e = hswap.privatePostSwapCancel( {'contract_code': coin.replace('PERP', 'USD'), 'order_id': str(ordid)} )
                                                
                                        #PrintException()
                            
                                if gogo == True:
                                    if direction == 'sell' and skews[coin.split('-')[0]] > wanting[coin] * 1.1  or direction == 'buy' and skews[coin.split('-')[0]] < wanting[coin] * 1.1 * mids['huobi'][coin]:
                                        if usdpos[coin.split('-')[0]] < wanting[coin]:
                                            offset = 'open'
                                        else:
                                            offset = 'close'
                                        hswap.privatePostSwapOrder( {'offset': offset, 'contract_code': coin.replace('PERP','USD'), 'price': prc, 'volume': wanting[coin], 'direction': direction, 'lever_rate': 10, 'order_price_type': 'post_only'})
                            
                        except:
                            PrintException()
                except:
                    PrintException()
            if c > 0:
                avg2 = t / c
                arbwinnersavg.append(avg2)
                arbwinnersc.append(c)
                c2 = c
                t = 0
                c = 0
                for arb in arbwinnersavg:
                    t = t + arb
                    c = c + 1
                avg3 = t / c
                print('%s are calculated based on 15x leverage, and double the funds available via cross margin borrowing (less about 36% APR for borrowing)')
                print('%s in Annual Percentage Yield')
                print('avg opportunity (over 20%): ' + str(round(avg*1000)/1000))
                #print('max opportunity (over 25%): ' + str(round(maxi*1000)/1000))
                print('# opps: ' + str(c1))
                print('avg opportunity over the avg: ' + str(round(avg2*1000)/1000))
                print('# opps over avg: ' + str(c2))
                print('avg of ' + str(c) + ' minute-long runs: ' + str(round(avg3*1000)/1000))
                day = avg3 / 365
                day = 100 / day
                print('doubling money every ' + str(round(day*1000)/1000) + ' days!')
                print(' ')
                #print('max of all to date: ' + str(round(maxmax*1000)/1000))
                print(' ')
                # todo remove
        """
        for coin in coins:
            try:
                array = [mids['ftx'][coin + '-PERP'], mids['ftx'][coin + '-0925']]
                minimum = min(array)
                                    
                maximum = max(array)
            #           if coin == 'BTC':
            ##               print(arbs[coin][dt])
            #              print(maximum / minimum)
                thearb = (((maximum / minimum)-1)*100)*365 * 10  #1.1/1.05 = 
                #print(thearb)
                #print(expis[dt])
                #print('thearb of ' + coin + ' at ' + dt + ' in total ' + str(thearb)) 
                thearb = thearb / expis['0925']
                #print(thearb)
                #print( ' ' )
                if thearb > 5 and coin != 'USDT':
                   # print(exes[coin][dt])
                    thearbs.append({'coin': coin, 'thearb': thearb})
                    print({'coin': coin, 'thearb': thearb})
              #  print('and after figuring out daily arb it\'s ' +  str(thearb))
            except:
                abc=123#PrintException()
        
        premiumwinners = []
        for arb in thearbs:
            if arb['coin'] != 'USDT':
               # print(arb)
                premiumwinners.append(arb)
        """
    except:
        PrintException()
        abc=123
ftx	 = ccxt.ftx({
'apiKey': apikey,   
            'secret': apisecret,
'enableRateLimit': True

})

cancelall()
sizeIncrements = {}
r = requests.get('https://ftx.com/api/markets').json()['result']
#for m in r:
    #sizeIncrements[m['name']] = m['sizeIncrement'] 
markets = binance.fetchMarkets()
futs = '200925'
for m in markets:
    #print(m['id'])
    try:
        binance.dapiPrivatePostLeverage({'symbol': m['id'], 'leverage': 75})
    except:
        abc=123
        
from HuobiDMService import HuobiDM
from pprint import pprint

#### input huobi dm url
URL = 'https://api.hbdm.com/swap-'
URL2 = 'https://api.hbdm.com'
####  input your access_key and secret_key below:



hswap = ccxt.huobiswap({
'apiKey': apikey,   
            'secret': apisecret,
'enableRateLimit': True})
hfutures = ccxt.huobifuts({
'apiKey': apikey,   
            'secret': apisecret,
'enableRateLimit': True})

huobi = ccxt.huobipro({"urls": {'api':{'public': 'https://api.hbdm.com/swap-api',
'private': 'https://api.hbdm.com/swap-api'}}})

hspot = ccxt.huobipro({
'apiKey': apikey,   
            'secret': apisecret,
'enableRateLimit': True})
hspotm			   = hspot.fetchMarkets()

print('s,s,f')
print(len(hspotm))
print(dir(hspot))
insts			   = binance.fetchMarkets()
#print(insts[0])

bin_futures_all	=	insts
funding = {}
exchanges = ['huobi']
mids = {}
bids = {}
asks = {}
for ex in exchanges:
    funding[ex] = {}
    mids[ex] = {}
    bids[ex] = {}
    asks[ex] = {}
expis = {}
futureends = ["_CW", "_NW", "_CQ", "_NQ"]
precisions = {}
ticksizes = {}
rates = {}
for ex in exchanges:
    rates[ex] = {}
huobisw = []
huobis = []
huobi = requests.get("https://api.hbdm.com//swap-api/v1/swap_contract_info").json()['data']

for market in huobi:
    #stri = str(huobi[market])
        #if 'usd' in market['quoteId']:
    if market['contract_code'] not in huobisw:
        huobisw.append(market['contract_code'])

huobi = requests.get("https://api.hbdm.com/api/v1/contract_contract_info").json()['data']

dts = []
for market in huobi:
    #stri = str(huobi[market])
        #if 'usd' in market['quoteId']:
    if market['symbol'] not in huobis:
        huobis.append(market['symbol'])
        sizeIncrements[market['symbol']] = market['contract_size']
    dt = market['delivery_date']
    expiry  = datetime.datetime.strptime( 
                                           dt, 
                                            '%Y%m%d' )
            
    #print(dt)
    dt = dt[-4:]
    if dt not in dts:
        dts.append(dt)			
    now	 = datetime.datetime.utcnow()

    days	= ( expiry - now ).total_seconds() / SECONDS_IN_DAY
    #print(days)
    expis[dt] = days
    expis['PERP'] = 30000
    #print(expis)

    #print(huobi[market])
"""
bcontracts = []

pairs = requests.get('https://dapi.binance.com/dapi/v1/exchangeInfo').json()
for symbol in pairs['symbols']:
    split = len(symbol['baseAsset'])
    #if 'BTC' in symbol['symbol']:
        #print(symbol['symbol'])
    normalized = symbol['symbol'][:split] + '-' + symbol['symbol'][split:]
    bcontracts.append(normalized)
config = {TICKER: bcontracts}
fh.add_feed(BinanceFutures(config=config, callbacks={TICKER: TickerCallback(ticker)}))

ofuts = []
oswaps = []
swaps = requests.get('https://www.okex.com/api/swap/v3/instruments').json()

futures = requests.get('https://www.okex.com/api/futures/v3/instruments').json()
for s in swaps:
    oswaps.append(s['instrument_id'])
for f in futures:
    ofuts.append(f['instrument_id'])
config = {TICKER_OKS: oswaps
,TICKER_FUTURES: ofuts}
fh.add_feed(OKEx(config=config, callbacks={TICKER_FUTURES: TickerCallback(ticker), TICKER_OKS: TickerCallback(ticker)}))

#print(expis)
takens = []
dts.sort()
#print(dts)
times = {"_CW": dts[0], "_NW": dts[1], "_CQ": dts[2], "_NQ": dts[3]}
for fut in bin_futures_all:
    try:
        split = (fut['info']['symbol']).split('_')[1][-4:]
        
        expi = datetime.datetime.fromtimestamp(fut['info']['deliveryDate'] / 1000)

        now	 = datetime.datetime.utcnow()
        days	= ( expi - now ).total_seconds() / SECONDS_IN_DAY
        #print(days)
        #print(days)
        expis[split] = days
        precisions[fut['info']['symbol']] = 1
        ticksizes[fut['info']['symbol']] = 1
        for precision in range(0, fut['info']['pricePrecision']):
            precisions[fut['info']['symbol']] = precisions[fut['info']['symbol']] / 10
            ticksizes[fut['info']['symbol']]= ticksizes[fut['info']['symbol']] / 10
        #print(fut['info']['symbol'])
        #print(ticksizes_binance[fut['info']['symbol']])
        #print(precisions_binance[fut['info']['symbol']])
    except:
        PrintException()

ftx = requests.get("https://ftx.com/api/funding_rates").json()['result']
doneFtx = {}
for rate in ftx:
    doneFtx[rate['future'].replace('-PERP', '')] = False
for rate in ftx:
    if rate['future'].replace('-PERP', '') != 'BTC' and rate['future'].replace('-PERP', '') != 'ETH':
        if doneFtx[rate['future'].replace('-PERP', '')] == False:
            doneFtx[rate['future'].replace('-PERP', '')] = True
            rates['ftx'][rate['future'].replace('-PERP', '')] = rate['rate'] * 24

"""
allfuts = []
expiries = {}
hcontracts = []
for contract in huobis:
    for futureend in futureends:
        hcontracts.append(contract + futureend)
        

#for contract in huobisw:
#    hcontracts.append(contract)

config = {L2_BOOK: hcontracts}
fh.add_feed(hdm(config=config, callbacks={L2_BOOK: BookCallback(book)}))
kcontracts = []
"""
binance = requests.get("https://dapi.binance.com/dapi/v1/premiumIndex").json()
#binance_f = requests.get("https://fapi.binance.com/fapi/v1/premiumIndex").json()
kraken = requests.get("https://futures.kraken.com/derivatives/api/v3/tickers").json()

for market in kraken['tickers']:
    if 'tag' in market:
        kcontracts.append(market['symbol'].upper())
#print(kcontracts)
config = {TICKER: kcontracts}
fh.add_feed(KrakenFutures(config=config, callbacks={TICKER: TickerCallback(ticker)}))

fcontracts = []
ftxmarkets = requests.get("https://ftx.com/api/futures").json()['result']
for market in ftxmarkets:
    if 'MOVE' not in market['name'] and 'HASH' not in market['name']:
        fcontracts.append(market['name'])
config = {TICKER: fcontracts}
fh.add_feed(FTX(config=config, callbacks={TICKER: TickerCallback(ticker)}))
#loop = asyncio.get_event_loop()
"""
t = threading.Thread(target=loop_in_thread, args=())
t.start()

#t = threading.Thread(target=loop_in_thread2, args=())
#t.start()
print(expis)

import random, string
import requests
import math

funding = {}
exchanges = ['binance']#['binance', 'kraken', 'ftx', 'phemex', 'okex']
for ex in exchanges:
    funding[ex] = {}
def randomword(length):
	   letters = string.ascii_lowercase
	   return ''.join(random.choice(letters) for i in range(length))
def doupdates():
    global fundingwinners
    #todo: replace with dapi.binance.com/, and change all of the ccxt stuff in ccxt/binance.py to dapi.binance.com
    binance2 = requests.get('https://dapi.binance.com/dapi/v1/premiumIndex').json()
    for obj in binance2:
        try:
            funding['binance'][obj['symbol'].replace('USDT', '')] = float(obj['lastFundingRate']) * 3
        except:
            abc=123
    """
    kraken = requests.get('https://futures.kraken.com/derivatives/api/v3/tickers').json()['tickers']
    for obj in kraken:
        if 'tag' in obj:
            if obj['tag'] == 'perpetual':
                funding['kraken'][obj['pair'].replace('XBT','BTC').replace(':USD', '')] = float(obj['fundingRate']) * 3
           
    ftx = requests.get('https://ftx.com/api/funding_rates').json()['result']
    takenftx = []
    for obj in ftx:
        if obj['future'].replace('-PERP','') not in takenftx:
            takenftx.append(obj['future'].replace('-PERP',''))
            funding['ftx'][obj['future'].replace('-PERP','')] = float(obj['rate']) * 24
    
    phemproducts = requests.get('https://api.phemex.com/exchange/public/cfg/v2/products').json()['data']['products']
    phemperps = []
    for obj in phemproducts:
        if obj['type'] == 'Perpetual':
            phemperps.append(obj['symbol'])
    for perp in phemperps:
        phemex = requests.get('https://api.phemex.com/md/ticker/24hr?symbol=' + perp).json()['result']
        funding['phemex'][perp.replace('USD', '')] = float(phemex['fundingRate'])/100000000*3
        
    
    swaps = requests.get('https://www.okex.com/api/swap/v3/instruments').json()
    for s in swaps:
        okex = requests.get('https://www.okex.com/api/swap/v3/instruments/' + s['instrument_id'] + '/funding_time').json()
        funding['okex'][okex['instrument_id'].replace('-USDT-SWAP', '').replace('-USD-SWAP', '')] = float(okex['funding_rate']) * 3
    """
    rates = {}
    for ex in funding:
        rates[ex] = {}
        for coin in funding[ex]:
            rates[ex][coin] = []
    for ex in funding:
        for coin in funding[ex]:
            rates[ex][coin].append(float(funding[ex][coin]))
    APRS = {}
    longshorts = {}
    for ex in rates:
        APRS[ex] = {}
        for coin in rates[ex]:
                
            maximum = max(rates[ex][coin])
            minimum = min(rates[ex][coin])
      #      print(coin)
      #      print(math.fabs(maximum) * 100)
      #      print(math.fabs(minimum) * 100)     
      #      print(str(0.015*3))
      #      print(' ')
            if math.fabs(maximum) > math.fabs(minimum):
                if (math.fabs(maximum) * 365 * 100 * 75 / 2) - minArb > 0:
                    if maximum < 0:
                        longshorts[coin] = 'long'
                    else:
                        longshorts[coin] = 'short'
                    APRS[ex][coin] = (math.fabs(maximum) * 365 * 100 * 75 / 2) - minArb
            else:
                if  (math.fabs(minimum) * 365 * 100 * 75 / 2) - minArb > 0:
                    if minimum < 0:
                        longshorts[coin] = 'long'
                    else:
                        longshorts[coin] = 'short'
                    APRS[ex][coin] = (math.fabs(minimum) * 365 * 100 * 75 / 2) - minArb

    
    fundingwinners = []
    t = 0
    c = 0
    for ex in APRS:
        maximum = 0

        winner = ""
        for coin in APRS[ex]:
            if APRS[ex][coin] > 0 and 'LINK' in coin or 'BTC' in coin or 'ETH' in coin or 'ADA' in coin:
                t = t + APRS[ex][coin]
                c = c + 1
                
                fundingwinners.append({'ex': ex, 'coin': coin, 'arb': APRS[ex][coin]})
     #           print({'ex': ex, 'coin': coin, 'arb': APRS[ex][coin]})
       #print('The Maximum funding opportunity on ' + ex + ' now is ' + winner + ' with ' + str(maximum) + '%!')
    percs = {}
    tobuy = {}
    for ex in APRS:
        maximum = 0

        winner = ""
        for coin in APRS[ex]:
            
            if APRS[ex][coin] > 0 and 'LINK' in coin or 'BTC' in coin or 'ETH' in coin or 'ADA' in coin:
                    percs[coin] = 1#APRS[ex][coin] / t
                                   #((1000000 * 0.66) * 75 /2) / 10
                    #((25 * 0.25 ) * 75 / 2) / 10
                    
                    tobuy[coin] = ((balances[coin.split('_')[0].replace('USD', '')] * percs[coin]) * 75 / 2) / 10
                    tobuy[coin.replace('PERP', futs)] = tobuy[coin] * -1
                    
            elif 'LINK' in coin or 'BTC' in coin or 'ETH' in coin or 'ADA' in coin:
                tobuy[coin] = 0
                tobuy[coin.replace('PERP', futs)] = 0
    print(percs)        
    for coin in longshorts:
        if longshorts[coin] == 'short':
            try:
                tobuy[coin] = tobuy[coin] * -1
                tobuy[coin.replace('PERP', futs)] = tobuy[coin.replace('PERP', futs)] * -1
            except:
                abc=123
    print(tobuy)
    #sleep(100)
    for coin in tobuy:
        #cancelall(coin)
        #-100 btc
        #-800 
        #100
        #800
        try:
            
        
            if math.fabs((tobuy[coin]) / (balances[coin.split('_')[0].replace('USD', '')] * 75)) > ((1/divisor) * 0.5) / 75: 
                        
                if 'BTC' in coin:
                    tobuy[coin] = tobuy[coin] / 10
                    tobuy[coin] = tobuy[coin] - pos[coin] / 10
                else:
                    tobuy[coin] = tobuy[coin] - pos[coin] / 100
                #print(tobuy)
                direction = 'BUY'
                if tobuy[coin] < 0:
                    direction = 'SELL'
                    tobuy[coin] = tobuy[coin] * -1
                if tobuy[coin] != 0:
                    #print(tobuy[coin])
                    bbo = mids['binance'][coin.replace('USD', '-USD')]
                    
                    print(int(tobuy[coin] / divisor))
                    print(tobuy[coin])
                    if direction == 'SELL':
                        
                        binance.dapiPrivatePostOrder(  {'timeInForce': 'GTC', 'symbol': coin, 'side': direction, 'type': 'LIMIT', 'price': bbo['bid'], 'quantity': int(tobuy[coin] / divisor),"newClientOrderId": "x-v0tiKJjj-" + randomword(15)})
                    else:
                        binance.dapiPrivatePostOrder(  {'timeInForce': 'GTC', 'symbol': coin, 'side': direction, 'type': 'LIMIT', 'price': bbo['ask'], 'quantity': int(tobuy[coin] / divisor),"newClientOrderId": "x-v0tiKJjj-" + randomword(15)})
        except:
            PrintException()
    print(tobuy)
balances = {}
totrade = ['BTC', 'ETH', 'LINK', 'ADA']
pos = {}
usdpos = {}
skews = {}
balancereal2 = 0
for t in totrade:
    balances[t] = 0
def updatePositions():
    
    try:
        global positions, skews, balancereal, balancereal2
        skews = {}
        balancereal2 = balance
        for coin in coinsto:
            skews[coin] = 0   
            positions	   = hfutures.privatePostContractAccountPositionInfo({'symbol': coin})
        
            for p in positions['data']: 
                
                #if p['entryPrice'] is not None:
                #    print(p)
                for pos in p['positions']:
                    balancereal2 = balancereal2 + float(pos['profit_unreal'])
                    balancereal2 = balancereal2 + float(pos['profit'])
                    
                    name = p['symbol'] + '-' +pos['contract_code'][:-4]
                    
                    size = float(pos['volume'])
                    if pos['direction'] == 'sell':
                        size = size * -1
                    pos[name] = size
                    usdpos[name] = float(pos['cost_hold'])
            
                for pos in p['positions']:
                    size = float(pos['cost_hold'])
                    if pos['direction'] == 'sell':
                        size = size * -1
                    
                    skews[p['symbol']] = skews[p['symbol']] + size
            print(skews)
            positions = hswap.privatePostSwapAccountPositionInfo   ({'contract_code': coin+ '-USD'}) 
            for p in positions['data']: 
            
                #if p['entryPrice'] is not None:
                #    print(p)
                for pos in p['positions']:
                    name = p['symbol'] + '-PERP'
                    balancereal2 = balancereal2 + float(pos['profit_unreal'])
                    balancereal2 = balancereal2 + float(pos['profit'])
                    if coin == 'EOS':
                        print(pos)
                    size = float(pos['volume'])
                    if pos['direction'] == 'sell':
                        size = size * -1
                    pos[name] = size
                    usdpos[name] = float(pos['cost_hold'])
            
                for pos in p['positions']:
                    size = float(pos['cost_hold'])
                    if pos['direction'] == 'sell':
                        size = size * -1
                    
                    skews[p['symbol']] = skews[p['symbol']] + size
            print(skews)
        sleep(2)
    except Exception as e:
        PrintException()
    with open('huobi.json', 'w') as outfile:
        json.dump({'balance': balancereal2, 'startbalance': balancereal}, outfile)

    
import json

lev = 0
marginbs = {}
spotbs = {}
futbs = {}
swapbs = {}
#balance = 500
balance = 0
balancereal = 0 
first = True
def updateBalance():
   
    print('ub')
    try:
        
        global balance, lev, first, balancereal, balancereal2
        bal2 = hfutures.privatePostContractAccountInfo()
        bal3 = hswap.privatePostSwapAccountInfo()
        for b in bal2['data']:
            if b['symbol'] in coinsto:
                usdpos[b['symbol']] = 0
        for b in bal3['data']:
            if b['symbol'] in coinsto:
                usdpos[b['symbol']] = 0
        for b in bal2['data']:
            if b['symbol'] in coinsto:
                print(b)
                if float(b['margin_balance']) > 0:
                    futbs[b['symbol']] = float(b['margin_balance'])
                #usdpos[b['symbol']] = usdpos[b['symbol']] + float(b['margin_position'])
        for b in bal3['data']:
            if b['symbol'] in coinsto:
                print(b)
                if float(b['margin_balance']) > 0:
                    swapbs[b['symbol']] = float(b['margin_balance'])
                #usdpos[b['symbol']] = usdpos[b['symbol']] + float(b['margin_position'])
        print(futbs)
        print(swapbs)
        #sleep(100)
        """
        account_balance_list = account_client.get_account_balance()
        if account_balance_list and len(account_balance_list):
            for account_obj in account_balance_list:
                account_obj.print_object()
                print()
        
        sleep(100)
        """
        #bal2 = hfutures.get_contract_account_info()
        balspot = hspot.fetchBalance()
        for bal in balspot['free']:
            spotbs[bal] = balspot['free'][bal]
        print(spotbs['USDT'])
        if spotbs['USDT'] > 10:
            hspot.privatePostCrossMarginTransferIn({'currency': 'usdt', 'amount': str(spotbs['USDT'])})
        for spot in spotbs:
            try:
                if spot != 'USDT' and spotbs[spot] > 0:
                    hspot.v2PrivatePostAccountTransfer({'from': 'spot', 'to': 'swap', 'currency': spot, 'amount': str(spotbs[spot] / 2)}) 
                    hspot.privatePostFuturesTransfer({'type': 'pro-to-futures', 'currency': spot, 'amount': str(spotbs[spot] / 2)})
            except:
                PrintException()
        print(spotbs)
        #sleep(100)
        bal3 = hspot.privateGetCrossMarginAccountsBalance()
        try:
            for bal in bal3['data']['list']:
                try:
                    if bal['currency'] == 'usdt':
                        print(bal)
                        if bal['type'] == 'trade':
                            marginbs[bal['currency']] = float(bal['balance'])
                    elif bal['type'] == 'transfer-out-available':
                        marginbs[bal['currency']] = float(bal['balance'])
                        
                except:
                    abc=123
            #sleep(100)
            balance = marginbs['usdt']
            if first == True:
                first = False
                balancereal = balance
            print(marginbs)
            for m in marginbs:
                try:
                    print(m)
                    print(1)
                    if m != 'usdt' and float(marginbs[m]) > 0:
                        print(2)
                        print(marginbs[m])
                        margt = hspot.privatePostCrossMarginTransferOut({'currency': m, 'amount': str(round(marginbs[m] * 1000)/ 1000)})
                        print(margt)
                except: 
                    PrintException()
            print('b')
            print(balance)
        except Exception as e:
            PrintException()
            #sleep(500)
            abc=123
            
        
        #balance = 228
        print(marginbs)
        """
        pprint(marginbs)
        #sleep(1)
        pprint(bal1)
        pprint(bal2)
        newbal = 0
        ##print(bal2)
        for coin in bal2['info']['result']:
            newbal = newbal + coin['usdValue']  
        t = 0
        for pos in usdpos:
            t = t + math.fabs(usdpos[pos])
        lev = t / newbal * 100
        balance = newbal
        print(balance)
        print(lev)
        balance = 50000
        """
    except:
        PrintException()
        abc=123
        
    
    #balance = 500

updateBalance()
updatePositions()

try:
    for coin in coinsto:
        coin = coin.lower()
        loans = hspot.privateGetCrossMarginLoanOrders({'size': "100",'currency': coin, 'state': 'accrual'})
        for l in loans['data']:
            try:
                if float(l['loan-balance']) > 0:
                    torepay = float(l['loan-balance'])
                    identifier = l['id']
                    print({'from': 'swap', 'to': 'spot', 'currency': coin, 'amount': str(torepay / 2)})
                    try:
                        hspot.v2PrivatePostAccountTransfer({'from': 'swap', 'to': 'spot', 'currency': coin, 'amount': str(torepay / 2)}) 
                    except:
                        PrintException()
                        
                        
                    try:
                        hspot.privatePostFuturesTransfer({'type': 'futures-to-pro', 'currency': coin, 'amount': str(torepay / 2)})
                    except:
                        PrintException()
                    try:
                        hspot.privatePostCrossMarginTransferIn({'currency': coin, 'amount': str(torepay)})
                    except:
                        PrintException()
                    
                    torepay = float(l['interest-amount'])
                    try:
                        hspot.v2PrivatePostAccountTransfer({'from': 'swap', 'to': 'spot', 'currency': coin, 'amount': str(torepay / 2)}) 
                    except:
                        PrintException()
                        
                        
                    try:
                        hspot.privatePostFuturesTransfer({'type': 'futures-to-pro', 'currency': coin, 'amount': str(torepay / 2)})
                    except:
                        PrintException()
                    try:
                        hspot.privatePostCrossMarginTransferIn({'currency': coin, 'amount': str(torepay)})
                    except:
                        PrintException()
                    try:
                        hspot.privatePostCrossMarginOrdersIdRepay({'id': identifier, 'amount': str(torepay)})
                    except: 
                        PrintException()
                    #hspot.privatePostCrossMarginOrdersIdRepay({'id': identifier, 'amount': str(toborrow / mids['huobi'][arb])})
            except Exception as e:
                PrintException()
                sleep(2)
except Exception as e:
    PrintException()
    sleep(2)

#sleep(25)
for contract in huobisw:
    if contract.split('-')[0] in huobis and contract.split('-')[0] in coinsto:
        data = requests.get("https://api.hbdm.com/swap-ex/market/detail/merged?contract_code=" + contract).json()['tick']
        ask = data['ask'][0]
        bid = data['bid'][0]
        name = contract.split('-')[0]
        dt = 'PERP'
        ex = 'huobi'
        mids[ex][name + '-' + dt] = 0.5 * ( float(ask) + float(bid))
        bids[ex][name + '-' + dt] = float(bid)
        asks[ex][name + '-' + dt] = float(ask) 
        #print(name)
"""
arb = 'BTC-PERP'
toborrow = 100    
#hspot.privatePostAccountTransfer({'from': 'swap', 'to': 'spot', 'currency': arb.split('-')[0].lower(), 'amount': str(0.005)}) 
#hspot.privatePostFuturesTransfer({'type': 'futures-to-pro', 'currency': arb.split('-')[0].lower(), 'amount': str(0.005)})
#wantingold[arb.split('-')[0]] = toborrow
#hspot.privatePostCrossMarginTransferIn({'currency': arb.split('-')[0].lower(), 'amount': str(toborrow / mids['huobi'][arb])})
#borrowed = hspot.privatePostCrossMarginOrders({'symbol': arb.split('-')[0].lower() + 'usdt', 'currency': arb.split('-')[0].lower(), 'amount':  str( round((toborrow * 1.01) / mids['huobi'][arb] * 1000)/ 1000)})   
loans = hspot.privateGetCrossMarginLoanOrders({'currency': arb.split('-')[0].lower(), 'state': 'accrual'})
for l in loans['data']:
    if float(l['loan-balance']) > 0:
        torepay = l['loan-balance'] 
        print(torepay)
        identifier = l['id']
        hspot.privatePostCrossMarginOrdersIdRepay({'id': identifier, 'amount': str(torepay)})
"""
#sleep(25)
while True:
    r = random.randint(0, 1000)
    if r <= 5:
        cancelall()
    updateBalance()
    updatePositions()
    for ex in mids:
        for dt in mids[ex]:
            if dt.split('-')[1] not in expis:
                try:
                
                    if 'PERP' in dt:
                        expis[dt.split('-')[1]] = 30000
                    else:
                        now	 = datetime.datetime.utcnow()
                        expiry  = datetime.datetime.strptime( 
                                                   '2021' + dt.split('-')[1], 
                                                    '%Y%m%d' )
                        days	= ( expiry - now ).total_seconds() / SECONDS_IN_DAY
                        print(days)
                        print(dt.split('-')[1])
                        expis[dt.split('-')[1]] = days
                except:
                    abc=123
    
    doCalc()
   #sleep(1)
    #sleep(20)
    #updateBalance()
    #sleep(5)
    #doupdates()
    #sleep(35)
